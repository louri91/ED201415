var prueba__gs1_8cpp =
[
    [ "load", "prueba__gs1_8cpp.html#af41987fe443f1dd30d3d55060e26dbc1", null ],
    [ "main", "prueba__gs1_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];