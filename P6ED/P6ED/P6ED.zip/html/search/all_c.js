var searchData=
[
  ['reading_5fgs1set',['reading_gs1Set',['../classgs1_set.html#a93f792f04522755886a1d3f16751b179',1,'gs1Set']]],
  ['root',['root',['../classtree.html#a6f4b4993040cc1f8316e31fddbca9e90',1,'tree']]]
];
