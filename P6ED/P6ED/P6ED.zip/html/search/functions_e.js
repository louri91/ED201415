var searchData=
[
  ['tree',['tree',['../classtree.html#ae79eee474e984b533cfaf3b0f29868ef',1,'tree::tree()'],['../classtree.html#a24cafcc1062cd99be8ae5ad395644aba',1,'tree::tree(const T &amp;e)'],['../classtree.html#a3a1b5515063305b3b4ecd0ebb3c22af6',1,'tree::tree(const tree&lt; T &gt; &amp;a)']]]
];
