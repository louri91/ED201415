var searchData=
[
  ['tree_3c_20t_20_3e',['tree&lt; T &gt;',['../classtree_1_1node.html#a580e66a56b1685f2fc7e95ded824a4b6',1,'tree::node::tree&lt; T &gt;()'],['../classtree_1_1const__node.html#a580e66a56b1685f2fc7e95ded824a4b6',1,'tree::const_node::tree&lt; T &gt;()']]]
];
